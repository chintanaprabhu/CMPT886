package ca.sfu.cmpt745.ex06;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SimpleTest {
  @Test
  public void shouldAnswerWithTrue() {
    assertTrue(true);
  }
}

