
package ca.sfu.cmpt745.ex06.examples;

import ca.sfu.cmpt745.ex06.kittens.Kitten;


public class Test_01_Basic {
  public void test() {
    Kitten kitten = new Kitten();
    kitten.pet();
    kitten.scare();
    kitten.feed();
  }
}

