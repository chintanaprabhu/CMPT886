
package ca.sfu.cmpt745.ex06.examples;

import ca.sfu.cmpt745.ex06.kittens.Kitten;


public class Test_00_Sanity {
  public void test() {
    // Where are my kittens?
  }
}

